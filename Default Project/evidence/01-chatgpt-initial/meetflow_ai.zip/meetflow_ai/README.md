# MeetFlow AI

MeetFlow AI turns meeting transcripts into summaries, decisions, and accountable tasks. It preserves decisions as versioned institutional memory, flags potential changes for explicit review, and keeps extracted tasks in a pending-approval queue until a human approves them.

## Features
- Executive summary, discussion points, and unresolved questions.
- Decision memory with versions and superseded history.
- Conflict review with **Confirm Change** and **Keep Previous Decision** choices.
- Speaker-attributed action extraction with deadline parsing and pending approval.
- Four-column Kanban board for approved tasks.
- Weekly digest and meeting-context chatbot.
- LLM extraction/chat using an OpenAI-compatible API when configured; deterministic extraction fallback for meeting analysis.
- Seeded launch-date demo and responsive browser UI.

## Stack
Python 3.11+, FastAPI, SQLAlchemy, SQLite, vanilla HTML/CSS/JavaScript, and an HTTP LLM API. No paid UI dependencies.

## Run locally
1. Install Python 3.11 or newer.
2. From this folder, create and activate a virtual environment:
   - Windows: `py -3.11 -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
3. Install dependencies: `pip install -r requirements.txt`
4. Copy `.env.example` to `.env`; optionally add `OPENAI_API_KEY`. (The app reads environment variables; load `.env` before launch with `set`/`export` or use `python-dotenv` integration.)
5. Run from the project root: `uvicorn backend.main:app --reload`
6. Open `frontend/index.html` in a browser. The UI calls the local API at `http://127.0.0.1:8000`. If browser CORS or file-origin restrictions arise, serve the frontend folder using `python -m http.server 5500 --directory frontend` and visit `http://127.0.0.1:5500`.

## Demo data
On first launch, two demo meetings seed the database: Launch Readiness Review sets 10 December 2026 and Ad-hoc Analytics Sync proposes 15 December 2026. One conflict appears for review and an unapproved checklist task is queued. SQLite file `meetflow.db` persists records. To reset demo data, stop the app, delete that database file, and restart.

## API endpoints
- `GET /api/health`, `/api/overview`, `/api/meetings`, `/api/meetings/{id}`
- `POST /api/meetings` (transcript extraction)
- `GET /api/decisions`, `/api/conflicts`, `/api/tasks`, `/api/digest`
- `POST /api/conflicts/{id}/review`
- `POST /api/tasks/{id}/approval`, `PATCH /api/tasks/{id}/status`
- `POST /api/chat`
- Interactive API docs: `http://127.0.0.1:8000/docs`

## Limitations
This MVP is not multi-user and has no authentication. LLM-backed chatbot answers require a valid API key and internet access. The fallback parser is heuristic, not a substitute for careful transcript review. Dates that are ambiguous are retained as phrases. Review proposed decisions and extracted task owners/deadlines before relying on them.
